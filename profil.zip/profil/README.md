# Profil_pro

<br> choix techniques :
<br> - J'ai fait un menu avec modification du style en fonction de l'endroit où l'on se situe dans la page
car cela permet d'avoir un menu mieux intégré à la page d'accueil et plus lisible au scroll
<br> - J'ai décidé de faire un fond avec effet parallaxe sur la page d'accueil afin de rendre
la navigation agréable pour l'utilisateur"
<br> - J'ai décidé de m'orienter vers un style du type "cartes" pour la partie expériences et formations car c'est une
solution que je sais utiliser et car je trouve cela orginal. Aussi ces cartes changent d'orientation en fonction de
la taille de l'écran (responsive)
<br> - Formulaire avec entrées (inputs) "borderless" afin d'être mieux intégé et rendre le formulaire agréable à regarder
<br> - ajout d'une barre de progression de lecture afin de mieux se rendre compte de la position dans le document

<br> adresse du host heroku :
<br> https://sitepersonn.herokuapp.com/
