//partie pour la barre de navigation afin de ne l'afficher que lorsque le visiteur passe la partie home
const nav = document.querySelector('.header');
const home = document.querySelector('.home');
let height = home.clientHeight;

window.addEventListener('scroll', () => {
    if(window.scrollY > height) {
        nav.classList.add('scroll');
    }
    else
    {
        nav.classList.remove('scroll');
    }
});

//partie pour la flèche afin de ne l'afficher que lorsque le visiteur passe la partie home
const footer = document.querySelector('.footer_fleche');

window.addEventListener('scroll', () => {
    if(window.scrollY > height) {
        footer.classList.add('scroll_fleche');
    }
    else
    {
        footer.classList.remove('scroll_fleche');
    }
});

//barre de progression horizontale
window.onload = () => {
    // Ecouteur d'évènement sur scroll 
    window.addEventListener("scroll", () =>
    {
        //calcul de la hauteur "utile" du document
        let hauteur = document.documentElement.scrollHeight - window.innerHeight
        
        // Récupération de la position verticale
        let position = window.scrollY

        // Récupération de la largeur de la fênetre
        let largeur = document.documentElement.clientWidth

        // Calcul de la largeur de la barre
        let barre = position / hauteur * largeur

        // Modification du CSS de la barre
        document.getElementById("progress").style.width = barre + "px"
    })


    // ----Liens Smooth vers les différentes parties----
    // Lien vers la partie à propos
    document.querySelector(".see_more").addEventListener("click", () => {
        document.getElementById("title_about").scrollIntoView({
            behavior: "smooth",
        });
    });

    // Lien vers la partie competences
    document.querySelector("#link_about").addEventListener("click", () => {
        document.getElementById("title_competences").scrollIntoView({
            behavior: "smooth",
        });
    });

    // Lien vers la partie experiences
    document.querySelector("#link_competences").addEventListener("click", () => {
        document.getElementById("title_experiences").scrollIntoView({
            behavior: "smooth",
        });
    });

    // Lien vers la partie formations
    document.querySelector("#link_exp").addEventListener("click", () => {
        document.getElementById("title_formation").scrollIntoView({
            behavior: "smooth",
        });
    });

    // Lien vers la partie formulaire de contact
    document.querySelector("#link_formation").addEventListener("click", () => {
        document.getElementById("title_form").scrollIntoView({
            behavior: "smooth",
        });
    });

    // Lien vers le haut
    document.querySelector("#footer_fleche").addEventListener("click", () => {
        document.querySelector(".home").scrollIntoView({
            behavior: "smooth",
        });
    });

    // Curseur personnalisé
    document.getElementsByClassName("home").onmousemove = (ev) => {
        // console.log(ev);
        const cursor = document.getElementsByClassName("cursor")[0];
        cursor.style.top = ev.clientY;
        cursor.style.left = ev.clientX;
    }

}
