<!DOCTYPE html>
<html lang="fr">
<head>
    <title>Mon profil professionnel</title>
    <meta charset="utf-8">
    <link rel="stylesheet" type="text/css" href="assets/style/style.css?9">
    <link rel="stylesheet" type="text/css" href="assets/fa/css/all.css?9">
</head>
<body>
    <div class="container">
    <?php 
        include_once "scripts/data.php";
        include_once "scripts/fonctions.php";
        include("scripts/header.php");
        mediasidebar($socialmedia);
        include("scripts/home.php");
        include("scripts/about.php");
        displayCompetences($competences);
        include("scripts/experience.php");
        displayFormation($formation);
        include("scripts/formulaire.php");
        footer($socialmedia);
    ?>
    </div>
    <footer class='footer_fleche'><a id='footer_fleche'><i class='fas fa-arrow-circle-up'></i></a></footer>
    <script src="app.js"></script>
</body>
</html> 