<div id="about" class="about">
    <h1 id="title_about" class="title_about"><?php echo $about['title']; ?></h1>
    <h2><?php echo $about['accroche']; ?></h2>
    <h2><?php echo $about['subtitle']; ?></h2>
    <p>
        <?php echo $about['moi']; ?>
    </p>
    <a href="assets/img/me.png" target="blank"><img alt="moi_de_dos" src="assets/img/me.png" class="img_me"></a>
    <a class="link_down" id="link_about"><i class="fas fa-chevron-down"></i></a>
</div>