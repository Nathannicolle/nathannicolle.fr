<?php
    $logo=['Nathan', 'NICOLLE'];
    $menu=['A propos' => '#about','Compétences' => '#competences','Expériences' => '#experiences','Formations' => '#formation','Contact' => '#container_formulaire'];
    $home=['Nathan NICOLLE', 'Le code ma passion !', 'voir plus'];
    $about=['title' => 'Nathan NICOLLE', 'subtitle' => 'Qui suis-je ?', 'accroche' => 'Le code ma passion !',
    'moi' => 'Je suis Nathan Nicolle étudiant en 2ème année de BTS SIO (Services Informatiques Aux Organisations). J\'ai commencé le code avec les langages d\'intégration HTML/CSS à l\'été 2018. 
    Mon objectif était au départ le développement de jeux-vidéos. Puis celui-ci à rapidement changé pour le développement web et le mobile. A terme 
    je souhaiterais devenir développeur fullstack et mobile. J\'ai assez rapidement eu un atrait pour le frontend mais aujourd\'hui j\'aime les défis apportés par le backend.'];
    $competences=
    [
        [
            'titlecompetences' => 'Compétences', 
            'titlecategorie' => 'Informatique, Développement et Technologies', 
            'description' => 'Langages de programmation et d\'intégration et technologies', 
            'competences' => 
            [
                [
                    'titleniveau' => 'Maitrise ++', 
                    'niveau' => 100, 
                    'items' => ['HTML/CSS', 'Bootstrap']
                ],
                [
                    'titleniveau' => 'Maitrise +', 
                    'niveau' => 50, 
                    'items' => ['PHP', 'MySQL/MariaDB', 'Javascript', 'Jquery', 'Wordpress', 'Arduino (C/C++)',]
                ],
                [
                    'titleniveau' => 'Demande + de pratique', 
                    'niveau' => 25, 
                    'items' => ['Java', 'Python', 'C#', 'méthode MVC (Modèle-Vue-Contrôleur)', 'Ubiquity (PHP)', 'Spring/Springboot (Java)', 'No-SQL']
                ]
                ]
        ]
    ];
    $experiences=[
        ['titre_exp' => 'Expériences', 'content_btn' => 'Télécharger mon cv', 'type_title' => 'Type : '],
        ['2018', '2019', '2020', '2021'],
        [
            'title_xp' => 'Stage à l\'IUT de Lannion',
            'type' => 'En entreprise',
            'poste' => 'Stagiaire dans le département Mesures Physiques', 
            'entreprise' => 'Institut Universitaire de Technologie (IUT) de Lannion', 
            'date' => 'Janvier 2018', 
            'duree' => '1 semaine', 
            'lieu' => 'Lannion, Bretagne (France)',
            'description' => 'Initiation à l’électronique et à la programmation avec <span class="p_color">Arduino</span> (C/C++). <br>
            Réalisation en une semaine d’un projet (applaudimètre) avec Arduino. <br>
            Découverte des différents services d’un IUT.'
        ],
        [
            'title_xp' => 'Création de mon site web',
            'type' => 'Hors entreprise',
            'poste' => 'Intégrateur web',
            'date' => 'été 2018',
            'duree' => 'environ 1 mois (entre la création et la mise en production)',
            'description' => 'Date de sortie de la première version du site : <br> 1er août 2018. <br> Date de mise en ligne : 
            <br> 19 septembre 2018. <br> Il est en constante évolution, avec des mises à jour régulières. 
            <br> <b>Langages utilisés :</b> <span class="p_color">HTML/CSS</span>'
        ],
        [
            'title_xp' => 'Mini projet BAC Terminale',
            'type' => 'Hors entreprise (lycée)',
            'poste' => 'Développeur',
            'entreprise' => 'Institut Lemonnier',
            'date' => 'du 12 novembre 2019 au 11 décembre 2019',
            'duree' => '1 mois',
            'lieu' => 'Caen, Normandie (France)',
            'description' => 'Préparation pour le projet BAC. <br>
            Projet panneau publicitaire rotatif. J\'étais chargé de faire tourner les faces du panneau rotatif
            à l\'aide d\'un moteur pas à pas. <br> <b>Langages utilisés :</b> <span class="p_color">C/C++</span> (Arduino)'
        ],
        [
            'title_xp' => 'Projet BAC Terminale',
            'type' => 'Hors entreprise (lycée)',
            'poste' => 'Développeur',
            'entreprise' => 'Institut Lemonnier',
            'date' => 'du 08 janvie 2020 au 11 mars 2020 (A cause de la situation)',
            'duree' => '2 mois environ',
            'lieu' => 'Caen, Normandie (France)',
            'description' => 'Le projet consistait en la surveillance d’un stationnement réservé aux personnes à mobilité réduite,
            afin que la place ne soit utilisée que par des personnes à mobilité réduite ou en situation de handicap.
            Mon rôle dans le projet a été de prendre en photo la plaque d\'immatriculation du véhicule d\'un contrevenant s\'étant 
            stationné sur la place de stationnement avant de l\'envoyer par <span class="p_color">mms</span> ou <span class="p_color">mail</span> à un contractuel. 
            <br> <b>Langages utilisés :</b> <span class="p_color">C/C++</span> (Arduino)'
        ],
        [
            'title_xp' => 'Nouvelle version de mon site',
            'type' => 'Hors entreprise',
            'poste' => 'Intégrateur web',
            'date' => 'été 2020',
            'duree' => 'environ 2 mois (entre la refonte et la mise en production)',
            'description' => 'J\'ai décidé de recoder à partir de zéro mon site pendant les vacances afin d\'y intégrer
            les connaissances que j\'ai acquises durant mon évolution entre le tout début du site et l\'été 2020. Aussi cela
            m\'a permis d\'abandonner bootstrap afin d\'être plus libre quant au style du site et ainsi avoir un contrôle
            total sur le code et savoir précisement comment chaque élément est codé.<br> <br> <b>Langages utilisés</b> : <br> <span class="p_color">HTML/CSS - Javascript - PHP</span>'
        ], 
        [
            'title_xp' => 'Apprentissage de connaissances et projets',
            'type' => 'Hors entreprise (études)',
            'poste' => 'étudiant',
            'entreprise' => 'CaenSup Sainte-Ursule',
            'date' => 'de septembre 2020 à mai 2021',
            'duree' => 'environ 264 jours',
            'lieu' => 'Caen, Normandie (France)',
            'description' => 'J\'ai pu durant cette première année de <span class="p_color">BTS SIO</span> (Services Informatiques aux Organisations) en apprendre énormément quant à la <span class="p_color">programmation</span> et ses concepts, avec notamment :
            <br/> - l\'apprentissage des bases du <span class="p_color">PHP</span>
            <br/> - du <span class="p_color">Javascript</span>
            <br/> - du <span class="p_color">C#</span>
            <br/> -de l\'admistration de Bases De Données avec <span class="p_color">SQL/MariaDB</span> notamment. 
            <br/> J\'ai également pu apprendre des bases par rapport à la partie
            <span class="p_color">réseau</span> (en tronc commun). Ainsi cet apprentissage que ce soit en développement ou en réseau s\'est notamment fait au travers de <span class="p_color">projets</span> seul ou en binôme.'
        ],
        [
            'title_xp' => 'Stage de première année de BTS SIO à l\'IUT de Lannion',
            'type' => 'En entreprise',
            'poste' => 'Stagiaire programmeur dans la Cellule de Regroupement Informatique (C.R.I)', 
            'entreprise' => 'Institut Universitaire de Technologie (IUT) de Lannion', 
            'date' => 'du 25 mai 2021 au 25 juin 2021', 
            'duree' => '1 mois (5 semaines environ)', 
            'lieu' => 'Lannion, Bretagne (France)',
            'description' => 'Mise en place d\'une application web permettant de récupérer des informations relatives à des matériels réseaux à partir d\'une application nommée zabbix et à partir
            de fichiers de configuration. Cette application m\'a permis d\'approfondir mes connaissances en PHP et d\'en apprendre beaucoup sur ce langage. J\'ai également eu la possibilité au travers
            de ce stage de découvrir la méthode M.V.C (Modèle-Vue-Contrôleur) qui est une méthode de projet utilisée en entreprise, très différente de ce dont j\'ai l\'habitude. Aussi
            j\'ai pu avoir un aperçu des méthodes et de l\'ambiance qu\'il est possible d\'avoir en entreprise. C\'est pour moi une expérience très enrichissante.'
        ],
        [
            'title_xp' => 'Stage de deuxième année de BTS SIO à Zaacom',
            'type' => 'En entreprise',
            'poste' => 'Stagiaire développeur fullstack',
            'entreprise' => 'Zaacom',
            'date' => 'du 6 décembre 2021 au 4 février 2022',
            'duree' => '7 semaines',
            'lieu' => 'Caen, Normandie (France)',
            'description' => 'Développement pour l’outil Workstation (SaaS) développé en interne par Zaacom d’une interface permettant
            la gestion et la visualisation de budgets (achats/prévisions) par année/mois pour la partie SEA. Ce stage
            m’a permis de travailler sur un projet en PHP et Javascript et ainsi d’approfondir mes connaissances de
            ces langages.'
        ]
    ];
    $formation=[
        ['titre' => 'Formations et diplôme', 'formation' => 
            [
                ['nom' => 'BTS Services Informatiques Aux Organisations (SIO)',
                'logo_formation' => 'assets/img/logo-CaenSup-noir.svg', 
                    'etablisssement' => 'CaenSup Sainte-Ursule', 
                    'date' => 'en cours', 
                    'lieu' => 'Caen, Normandie (France)',
                    'description' => 'Conception et administration de bases de données, conception Web, génie logiciel, cybersécurité et configuration de réseaux, architecture informatique.', 
                    'langages' => 'Langages et outils :', 
                    'langages_dsc' => 
                        ['HTML/CSS', 'PHP', 'Python', 'SQL', 'Javascript', 'Flutter/Dart'], 
                    'concepts' => 'Concepts :', 
                    'concepts_dsc' => 
                        ['Algorithmique', 'POO', 'méthode Merise']
                ],
                ['nom' => 'Baccalauréat Sciences et Technologies de l\'Industrie et du Développement Durable (STI2D)', 
                    'specialite' => 'Spécialité : ',    
                    'specialite_dsc' => 'Système d\'Information et Numérique (SIN)', 
                    'etablisssement' => 'Institut Lemonnier', 
                    'date' => '2018-2020', 
                    'lieu' => 'Caen, Normandie (France)', 
                    'description' => 'Systèmes électroniques, programmation sur microcontroleur, développement durable',
                    'langages' => 'Langages et outils :', 
                    'langages_dsc' => 
                        ['HTML/CSS', 'Arduino (C/C++)', 'LabView'], 
                    'concepts' => 'Concepts :', 
                    'concepts_dsc' => 
                        ['Algorithmique de base'],
                    'logo_formation' => 'assets/img/logo_lemonnier.svg'
                ]
            ]
        ]
    ];
    
    $formulaire=[
        ['title' => 'Me contacter'],
        ['title_field_firstname' => 'Prénom <sup title="requis">*</sup> :', 'title_field_name' => 'NOM <sup title="requis">*</sup> :', 'title_field_mail' => 'Email <sup title="requis">*</sup> :', 'title_field_message' => 'Votre message <sup title="requis">*</sup> :',]
    ];

    $socialmedia=['socialmedia' => 
        [
            [
                'lien' => 'https://nathannicolle.fr/',
                'id' => 'sm_link_website',
                'class_i' => 'fas fa-globe',
            ],
            [
                'lien' => 'mailto:contact@nathannicolle.fr',
                'id' => 'sm_link_mail',
                'class_i' => 'far fa-envelope'
            ],
            [
                'lien' => 'https://github.com/Nathannicolle',
                'id' => 'sm_link_github',
                'class_i' => 'fab fa-github'
            ],
            [
                'lien' => 'https://www.linkedin.com/in/nathan-nicolle/',
                'id' => 'sm_link_linkedin',
                'class_i' => 'fab fa-linkedin'
            ],
            [
                'lien' => 'https://www.instagram.com/nathannicolle2/',
                'id' => 'sm_link_insta',
                'class_i' => 'fab fa-instagram'
            ]
        ]
    ];
