<div class='experiences' id='experiences'>
<h1 id="title_experiences"> <?php echo $experiences[0]['titre_exp']; ?> </h1>
<div class='year2021'>
    <h1> <?php echo $experiences[1][3]; ?> </h1>
    <div class="card_group">
        <div class='card_exp card_exp_9'> <!-- Carte 7 - Stage IUT 2ème année de BTS -->
                <div class='card_column_exp'>
                    <div class='part1_exp part1_card9'>
                        <a href='assets/img/logo_zaacom.png' target='blank'><img src='assets/img/logo_zaacom.png' alt='logo de supavenir'></a>
                    </div>
                    <div class='part2_exp part2_card1'>
                        <h1 class='card_exp_title'><?php echo $experiences[9]['title_xp']; ?></h1>
                    </div>
                    <div class='part3_exp part3_card1'>
                        <h2 class='card_exp_subtitle subtitle_principal_expo'><?php echo $experiences[9]['entreprise'] ?> </h2>
                        <h2 class='card_exp_subtitle subtitle_principal_expo'><?php echo $experiences[9]['poste'] ?> </h2>
                        <h2 class='card_exp_subtitle'><?php echo $experiences[9]['date'] .  "<br>" . $experiences[9]['duree']; ?> </h2>
                        <h2 class='card_exp_subtitle'><a href='https://is.gd/P7CLQR' target='blank'><i class='fas fa-search-location'></i></a> <?php echo $experiences[9]['lieu']; ?></h2>
                    </div>
                </div>
                <div class='part4_exp part3_card1'>
                    <p><b> <?php echo $experiences[0]['type_title'] . $experiences[9]['type'] . "</b><br>" . $experiences[9]['description']; ?> </p>
                </div>
        </div>
    </div>
    <div class='card_group'> 
        <div class='card_exp card_exp_8'> <!-- Carte 7 - Stage IUT 2ème année de BTS -->
                <div class='card_column_exp'>
                    <div class='part1_exp part1_card6'>
                        <a href='assets/img/iut-lannion_1.png' target='blank'><img src='assets/img/iut-lannion_1.png' alt='logo de iut de lannion'></a>
                    </div>
                    <div class='part2_exp part2_card1'>
                        <h1 class='card_exp_title'><?php echo $experiences[8]['title_xp']; ?></h1>
                    </div>
                    <div class='part3_exp part3_card1'>
                        <h2 class='card_exp_subtitle subtitle_principal_expo'><?php echo $experiences[8]['entreprise'] ?> </h2>
                        <h2 class='card_exp_subtitle subtitle_principal_expo'><?php echo $experiences[8]['poste'] ?> </h2>
                        <h2 class='card_exp_subtitle'><?php echo $experiences[8]['date'] .  "<br>" . $experiences[8]['duree']; ?> </h2>
                        <h2 class='card_exp_subtitle'><a href='https://is.gd/rn45m4' target='blank'><i class='fas fa-search-location'></i></a> <?php echo $experiences[8]['lieu']; ?></h2>
                    </div>
                </div>
                <div class='part4_exp part3_card1'>
                    <p><b> <?php echo $experiences[0]['type_title'] . $experiences[8]['type'] . "</b><br>" . $experiences[8]['description']; ?> </p>
                </div>
        </div>

        <div class='card_exp card_exp_7'> <!-- Carte 6 - Projets en 1ère année de BTS -->
                <div class='card_column_exp'>
                    <div class='part1_exp part1_card6'>
                        <a href='assets/img/logo-CaenSup-noir.svg' target='blank'><img src='assets/img/logo-CaenSup-noir.svg' alt='logo de supavenir'></a>
                    </div>
                    <div class='part2_exp part2_card1'>
                        <h1 class='card_exp_title'><?php echo $experiences[7]['title_xp']; ?></h1>
                    </div>
                    <div class='part3_exp part3_card1'>
                        <h2 class='card_exp_subtitle subtitle_principal_expo'><?php echo $experiences[7]['entreprise'] ?> </h2>
                        <h2 class='card_exp_subtitle subtitle_principal_expo'><?php echo $experiences[7]['poste'] ?> </h2>
                        <h2 class='card_exp_subtitle'><?php echo $experiences[7]['date'] .  "<br>" . $experiences[7]['duree']; ?> </h2>
                        <h2 class='card_exp_subtitle'><a href='https://is.gd/IvosuV' target='blank'><i class='fas fa-search-location'></i></a> <?php echo $experiences[7]['lieu']; ?></h2>
                    </div>
                </div>
                <div class='part4_exp part3_card1'>
                    <p><b> <?php echo $experiences[0]['type_title'] . $experiences[7]['type'] . "</b><br>" . $experiences[7]['description']; ?> </p>
                </div>
        </div>
    </div>
</div>
<div class='year2020'> <!-- Groupement de cartes (2020) -->
    <h1> <?php echo $experiences[1][2] ?> </h1>
    <div class='card_group'>
        <div class='card_exp card_exp_5'> <!-- Carte 5 - Mon site entièrement recodé -->
            <div class='card_column_exp'>
                <div class='part1_exp part1_card5'>
                    <a href='assets/img/Scr_site_refonte.png' target='blank'><img src='assets/img/Scr_site_refonte.png' alt='mon site V2'></a>
                </div>
                <div class='part2_exp part2_card1'>
                    <h1 class='card_exp_title'> <?php echo $experiences[6]['title_xp']; ?><br>(<a href='https://nathannicolle.fr/' target='blank'>nathannicolle.fr</a>)</h1>
                </div>
                <div class='part3_exp part3_card1'>
                    <h2 class='card_exp_subtitle subtitle_principal_expo'> <?php echo $experiences[6]['poste']; ?> </h2>
                    <h2 class='card_exp_subtitle'> <?php echo $experiences[6]['date'] .  "<br>" . $experiences[6]['duree']; ?> </h2>
                </div>
            </div>
            <div class='part4_exp part3_card1'>
                <p><b><?php echo $experiences[0]['type_title'] . $experiences[6]['type'] . "</b><br>" . $experiences[6]['description'] ?></p>
            </div>
        </div>
        <div class='card_exp card_exp_4'> <!-- Carte 4 - Projet BAC -->
                <div class='card_column_exp'>
                    <div class='part1_exp part1_card4'>
                        <a href='assets/img/project_bac.jpg' target='blank'><img src='assets/img/project_bac.jpg' alt='illustration de mon projet bac'></a>
                    </div>
                    <div class='part2_exp part2_card1'>
                        <h1 class='card_exp_title'><?php echo $experiences[5]['title_xp']; ?></h1>
                    </div>
                    <div class='part3_exp part3_card1'>
                        <h2 class='card_exp_subtitle subtitle_principal_expo'><?php echo $experiences[5]['entreprise'] ?> </h2>
                        <h2 class='card_exp_subtitle subtitle_principal_expo'><?php echo $experiences[5]['poste'] ?> </h2>
                        <h2 class='card_exp_subtitle'><?php echo $experiences[5]['date'] .  "<br>" . $experiences[5]['duree']; ?> </h2>
                        <h2 class='card_exp_subtitle'><a href='https://is.gd/PammH2' target='blank'><i class='fas fa-search-location'></i></a> <?php echo $experiences[4]['lieu']; ?></h2>
                    </div>
                </div>
                <div class='part4_exp part3_card1'>
                    <p><b> <?php echo $experiences[0]['type_title'] . $experiences[5]['type'] . "</b><br>" . $experiences[5]['description']; ?> </p>
                </div>
            </div>
        </div>
    </div>
<div class='year2019'>
    <h1> <?php echo $experiences[1][1]; ?> </h1>
    <div class='card_group'> <!-- Groupement de cartes (2019) -->
        <div class='card_exp card_exp_3'> <!-- Carte 3 - Mini projet (BAC) -->
            <div class='card_column_exp'>
                <div class='part1_exp part1_card3'>
                    <a href='assets/img/mini_project.jpg' target='blank'><img src='assets/img/mini_project.jpg' alt='illustration de mon mini projet bac'></a>
                </div>
                <div class='part2_exp part2_card1'>
                    <h1 class='card_exp_title'><?php echo $experiences[4]['title_xp']; ?></h1>
                </div>
                <div class='part3_exp part3_card1'>
                    <h2 class='card_exp_subtitle subtitle_principal_expo'><?php echo $experiences[4]['entreprise']; ?></h2>
                    <h2 class='card_exp_subtitle subtitle_principal_expo'><?php echo $experiences[4]['poste']; ?> </h2>
                    <h2 class='card_exp_subtitle'><?= $experiences[4]['date'] .  "<br>" . $experiences[4]['duree']; ?></h2>
                    <h2 class='card_exp_subtitle'> <a href='https://is.gd/PammH2' target='blank'><i class='fas fa-search-location'></i></a> <?php echo $experiences[4]['lieu']; ?></h2>
                </div>
            </div>
            <div class='part4_exp part3_card1'>
                <p><b><?php echo $experiences[0]['type_title'] . $experiences[4]['type'] . "</b><br>" . $experiences[4]['description']; ?> </p>
            </div>
        </div>
</div>
<div class='year2018'>
    <h1> <?php echo $experiences[1][0]; ?> </h1>
    <div class='card_group'> <!-- Groupement de cartes (2018) -->
        <div class='card_exp card_exp_2'> <!-- Carte 2 - Mon site -->
            <div class='card_column_exp'>
                <div class='part1_exp part1_card2'>
                    <a href='assets/img/Scr_site.png' target='blank'><img src='assets/img/Scr_site.png' alt='capture de mon site dans sa V1'></a>
                </div>
                <div class='part2_exp part2_card1'>
                    <h1 class='card_exp_title'><?php echo $experiences[3]['title_xp']; ?> <br>(<a href='https://nathannicolle.fr/' target='blank'>nathannicolle.fr</a>)</h1>
                </div>
                <div class='part3_exp part3_card1'>
                    <h2 class='card_exp_subtitle subtitle_principal_expo'><?php echo $experiences[3]['poste']; ?> </h2>
                    <h2 class='card_exp_subtitle'><?php echo $experiences[3]['date'] .  "<br>" . $experiences[3]['duree']; ?> </h2>
                </div>
            </div>
            <div class='part4_exp part3_card1'>
                <p><b><?php echo $experiences[0]['type_title'] . $experiences[3]['type'] . "</b><br>" . $experiences[3]['description']; ?> </p>
            </div>
        </div>
        <div class='card_exp card_exp_1'> <!-- Carte 1 - Stage IUT -->
            <div class='card_column_exp'>
                <div class='part1_exp part1_card1'>
                    <a href='assets/img/iut-lannion_1.png' target='blank'><img src='assets/img/iut-lannion_1.png' alt='logo iut de lannion'></a>
                </div>
                <div class='part2_exp part2_card1'>
                    <h1 class='card_exp_title'><?php echo $experiences[2]['title_xp']; ?></h1>
                </div>
                <div class='part3_exp part3_card1'>
                    <h2 class='card_exp_subtitle subtitle_principal_expo'><?php echo $experiences[2]['entreprise']; ?> </h2>
                    <h2 class='card_exp_subtitle'><?php echo $experiences[2]['poste']; ?></h2>
                    <h2 class='card_exp_subtitle'><?php echo $experiences[2]['date'] .  "<br>" . $experiences[2]['duree']; ?> </h2>
                    <h2 class='card_exp_subtitle'> <a href='https://is.gd/rn45m4' target='blank'><i class='fas fa-search-location'></i></a> <?php echo $experiences[2]['lieu']; ?> </h2>
                </div>
            </div>
            <div class='part4_exp part3_card1'>
                <p><b><?php echo $experiences[0]['type_title'] . $experiences[2]['type'] . "</b><br>" . $experiences[2]['description'] ?> </p>
            </div>
        </div>
    </div>
</div>
<a href='assets/CV_Nathan_NICOLLE_V18.pdf' class='btn_download' target='blank'> <?php echo $experiences[0]['content_btn']; ?></a>
<a class='link_down' id="link_exp"><i class='fas fa-chevron-down'></i></a>
</div>
</div>
</div>