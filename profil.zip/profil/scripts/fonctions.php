<?php
function displayLogo(array $logo) {
    ?><h1 class="logo"><a href="#">
    <?php foreach($logo as $index=>$item_logo) {
        if($index % 2 === 0) {
            $class="prenom";
        } else {
            $class="nom";
        }
        ?><b class='<?= $class ?>'><?= $item_logo ?></b>
    <?php } ?>
    </a></h1>
<?php } ?>

<?php
function displayMenu(array $menu) {
?> <input id="check_menu" type="checkbox">
    <label class="show_menu_btn" for="check_menu"><i class="fas fa-bars"></i></label>
    <ul class="menu">
<?php 
	foreach($menu as $item_menu=>$link) {
?>
	<li><a href="<?=$link?>"><?=$item_menu?></a></li>
<?php } ?>
	</ul><label for="check_menu" class="hide-menu-btn">
    <i class="fas fa-times"></i>
    </label>'
<?php } ?>

<?php 
function displayCompetences($competences) {
?>
<div class="competences" id="competences">
    <?php foreach($competences as $partie) { ?>
            <h1 id="title_competences"><?= $partie["titlecompetences"]; ?></h1>
            <h2><?= $partie["titlecategorie"]; ?> </h2>
            <h3><?= $partie["description"]; ?></h3>
            <div class='competences_level'>
                <?php foreach($partie['competences'] as $index=>$comp) {
                    if($index % 3 === 0) {
                        $id="firtsprogress";
                    }else{
                        $id="";
                    }
                ?>
                    <div class='competences_subcategory'>
                        <h2><?= $comp['titleniveau']; ?> </h2>
                        <progress value="<?= $comp['niveau']; ?>" max="100" class="<?= $id ?>"></progress>
                        <ul>
                            <?php foreach($comp['items'] as $langlist) { ?>
                                <li><?= $langlist ?></li>
                            <?php } ?>
                        </ul>
                    </div>
                <?php } ?>
            </div>
        <?php } ?>
    <a class="link_down" id="link_competences"><i class="fas fa-chevron-down"></i></a></div>
<?php } ?>

<?php 
function displayFormation($formation) { ?>
    <div class="formation" id="formation">
        <?php foreach($formation as $formationgroup) { ?>
        <h1 id="title_formation"><?= $formationgroup['titre']; ?></h1>
            <?php foreach($formationgroup['formation'] as $index=>$cardformation){ ?>
                <div class='card_formation'>
                    <div class='card_part1'>
                        <?php 
                        if($index % 2 == 0) {
                            $lien_lieu= "https://is.gd/OBl0LL";
                        } else {
                            $lien_lieu= "https://is.gd/PammH2";
                        } ?>
                        <img src="<?= $cardformation['logo_formation'] ?>" alt="logo établissements">
                        <h1 class='title_card1'><?= $cardformation['nom'] ?></h1>
                        <p class='subtitle_card1'> <?= $cardformation['etablisssement'] ?></p>
                        <p class='subcontent_card1'> <?= $cardformation['date'] ?></p>
                        <p class='subcontent_card1'><a href='$lien_lieu'><i class='fas fa-search-location'></i></a> <?= $cardformation['lieu'] ?></p>
                    </div>
                    <div class='card_part2'>
                        <p class='p_card1'><?= $cardformation['description'] ?></p>
                        <p class='p_card1'><b><?= $cardformation['langages'] ?></b>
                        <?php foreach($cardformation['langages_dsc'] as $listlangage) { ?>
                            <?= $listlangage . " "; ?>
                        <?php } ?>
                        </p>
                        <p class='p_card1'><b><?= $cardformation['concepts'] ?></b>
                            <?php foreach($cardformation['concepts_dsc'] as $listlangage) { ?>
                                <?= $listlangage . " "; ?>
                            <?php } ?>
                        </p>
                    </div>
                </div>
            <?php } ?>
        <?php } ?>
    <a class="link_down" id="link_formation"><i class="fas fa-chevron-down"></i></a></div>
<?php } ?>


<?php function mediasidebar($socialmedia) { ?>
    <div class='sm_side'>
    <?php foreach($socialmedia['socialmedia'] as $reseaux) { ?>
        <a href='<?= $reseaux['lien'] ?>' target='blank' class='<?= $reseaux['id'] ?>'><i class='<?= $reseaux['class_i'] ?>'></i></a>
    <?php } ?>
    </div>
<?php } ?>

<?php
function footer($socialmedia) { ?>
    <footer class='footer_principal'>
        <ul>
            <?php foreach($socialmedia['socialmedia'] as $reseaux) {
            ?><li><a href="<?= $reseaux['lien'] ?>" target="blank" class="<?= $reseaux['id'] ?>"><i class='<?= $reseaux["class_i"] ?>'></i></a></li>
            <?php } ?>
        </ul>
    <a href='mentions_legales.html' class='link_ml'>Mentions légales</a>
</footer>
<?php } ?>