<?php
    echo "<header class='header'>";
    displayLogo($logo);
    displayMenu($menu);
    echo "</header>";
    echo "<div id='progress'></div>";
