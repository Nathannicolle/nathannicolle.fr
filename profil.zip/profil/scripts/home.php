<div class="home">
    <a href="assets/img/photo_me.jpg" class="link_photo_me"><img src="assets/img/photo_me.jpg" id="photo_me" alt="photo de nathan nicolle"></a>
    <h1 class="title_home"> <?php echo $home[0]; ?> </h1>
    <h2 class='subtitle_home'><?php echo $home[1]; ?></h2>
    <a class='see_more'><?php echo $home[2]; ?> <br> <i class='fas fa-angle-double-down'></i>
</a>
</div>